# parth Assistant 🎙️

A **lightweight Android voice assistant** designed for low-end phones with 2GB RAM.

## ✨ Features
- 🎤 Voice recognition using Android's built-in SpeechRecognizer (no internet AI needed)
- 🔊 Text-to-speech using Android's built-in TTS engine
- 📴 Mostly offline — no cloud AI, no heavy models
- 🌙 Dark mode UI
- ⚡ Tiny APK (~5–8 MB after ProGuard)

## 🗣️ Voice Commands Supported

| Command | Action |
|---|---|
| "Open YouTube" | Opens YouTube app or website |
| "Open camera" | Opens camera app |
| "Turn on / off flashlight" | Toggles torch |
| "Play music" | Opens music player |
| "Tell a joke" | Tells a random joke |
| "Set alarm" | Opens alarm clock |
| "What time is it?" | Speaks current time |
| "What day is it?" | Speaks current date |
| "Open maps" | Opens Google Maps |
| "Open settings" | Opens system settings |
| "Flip a coin" | Heads or tails |
| "Roll a dice" | Random 1–6 |
| "Help" | Lists all commands |

---

## 🏗️ How to Build the APK

### Prerequisites
- **Android Studio** (Hedgehog 2023.1.1 or newer) — [Download](https://developer.android.com/studio)
- **Java JDK 8+** (bundled with Android Studio)
- **Android SDK** API level 21–34

---

### Step 1 — Open in Android Studio
1. Unzip `parth-assistant.zip`
2. Open Android Studio → **File → Open**
3. Select the `parth-assistant` folder
4. Wait for Gradle sync to finish (~1–2 minutes)

---

### Step 2 — Build Debug APK (for testing)
In Android Studio menu bar:
```
Build → Build Bundle(s) / APK(s) → Build APK(s)
```
Find the APK at:
```
app/build/outputs/apk/debug/app-debug.apk
```

Or from terminal:
```bash
cd parth-assistant
chmod +x gradlew          # Mac/Linux only
./gradlew assembleDebug   # Mac/Linux
gradlew.bat assembleDebug # Windows
```

---

### Step 3 — Install on Phone
**Option A — USB:**
```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

**Option B — File transfer:**
1. Copy the APK to your phone
2. Tap the APK file on your phone
3. Allow "Install from unknown sources" if prompted

---

### Step 4 — Build Release APK (for sharing/distribution)
```bash
./gradlew assembleRelease
```
> ⚠️ You'll need to sign the APK with a keystore. Android Studio can generate one via:
> **Build → Generate Signed Bundle / APK**

---

## 📁 Project Structure

```
parth-assistant/
├── app/
│   ├── src/main/
│   │   ├── java/com/parth/assistant/
│   │   │   ├── MainActivity.java        ← Main UI + mic button
│   │   │   ├── AssistantEngine.java     ← Rule-based command processor
│   │   │   ├── VoiceOutputManager.java  ← Android TTS wrapper
│   │   │   └── WakeWordService.java     ← Wake word stub
│   │   ├── res/
│   │   │   ├── layout/activity_main.xml ← Dark mode UI
│   │   │   ├── values/colors.xml        ← Color scheme
│   │   │   ├── values/themes.xml        ← App theme
│   │   │   └── drawable/                ← Vector icons
│   │   └── AndroidManifest.xml
│   ├── build.gradle
│   └── proguard-rules.pro
├── build.gradle
├── settings.gradle
└── gradle.properties
```

---

## ⚙️ Performance Details

| Metric | Value |
|---|---|
| Min SDK | Android 5.0 (API 21) |
| Target SDK | Android 14 (API 34) |
| Est. APK size | ~5–8 MB |
| RAM usage | ~40–80 MB |
| Offline capable | ✅ (except speech-to-text needs Google app) |
| No AI models | ✅ Pure rule-based |

---

## 🔧 Permissions Required

| Permission | Reason |
|---|---|
| `RECORD_AUDIO` | Voice input |
| `CAMERA` | Open camera command |
| `FLASHLIGHT` | Torch control |
| `SET_ALARM` | Alarm command |

---

## 🔊 Note on Speech Recognition

Android's `SpeechRecognizer` uses Google's speech engine on most phones, which may need a brief internet connection for recognition. For **fully offline** speech recognition, integrate [VOSK](https://alphacephei.com/vosk/android) (~50MB model) or [Picovoice Rhino](https://picovoice.ai/) into `MainActivity.java`.

---

## 🚀 Adding More Commands

Open `AssistantEngine.java` and add a new block:
```java
if (matches(cmd, "your phrase here", "alternate phrase")) {
    return new CommandResult("Response text", () -> {
        // Action code here
    });
}
```

That's it — no retraining, no models!
