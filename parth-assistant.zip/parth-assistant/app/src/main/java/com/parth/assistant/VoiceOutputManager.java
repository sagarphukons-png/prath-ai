package com.parth.assistant;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import android.util.Log;

import java.util.Locale;

/**
 * Lightweight TextToSpeech wrapper.
 * Uses Android's built-in TTS engine - no extra downloads needed.
 */
public class VoiceOutputManager {

    private static final String TAG = "VoiceOutput";
    private TextToSpeech tts;
    private boolean isReady = false;

    public VoiceOutputManager(Context context) {
        tts = new TextToSpeech(context, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = tts.setLanguage(Locale.getDefault());
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(Locale.ENGLISH);
                }
                // Slightly faster speech for snappy feel
                tts.setSpeechRate(0.95f);
                tts.setPitch(1.0f);
                isReady = true;
                Log.d(TAG, "TTS initialized successfully");
            } else {
                Log.e(TAG, "TTS initialization failed");
            }
        });
    }

    public void speak(String text) {
        if (!isReady || tts == null || text == null || text.isEmpty()) return;

        // Stop current speech before speaking new text
        if (tts.isSpeaking()) {
            tts.stop();
        }

        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "parth_tts_" + System.currentTimeMillis());
    }

    public void stop() {
        if (tts != null && tts.isSpeaking()) {
            tts.stop();
        }
    }

    public void shutdown() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
            tts = null;
        }
        isReady = false;
    }
}
